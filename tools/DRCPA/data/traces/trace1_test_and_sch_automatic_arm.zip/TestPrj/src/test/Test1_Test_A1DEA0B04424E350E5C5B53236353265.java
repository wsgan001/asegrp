/**@generated
 * WARNING ? Changes you make to this file may be lost.
 *           File is generated and may be re-generated without warning.
 */
package test;

import com.ibm.rational.test.lt.datacorrelation.execution.action.VariableAction;
import com.ibm.rational.test.lt.datacorrelation.execution.harvest.DataCorrelationVar;
import com.ibm.rational.test.lt.datacorrelation.execution.harvest.DataHarvester;
import com.ibm.rational.test.lt.datacorrelation.execution.harvest.DataVar;
import com.ibm.rational.test.lt.datacorrelation.execution.harvest.IDCCoreVar;
import com.ibm.rational.test.lt.datacorrelation.execution.harvest.IDataCorrelationVar;
import com.ibm.rational.test.lt.datacorrelation.execution.harvest.IDataHarvester;
import com.ibm.rational.test.lt.datacorrelation.execution.proto.ProtoAdapterHandler;
import com.ibm.rational.test.lt.datacorrelation.execution.sub.DataSub;
import com.ibm.rational.test.lt.datacorrelation.execution.sub.IDataSub;
import com.ibm.rational.test.lt.datacorrelation.execution.sub.ISubRule;
import com.ibm.rational.test.lt.datacorrelation.execution.sub.SubRule;
import com.ibm.rational.test.lt.execution.http.IBasicAuthentication;
import com.ibm.rational.test.lt.execution.http.IHTTPRequest;
import com.ibm.rational.test.lt.execution.http.IHTTPSessionTypes;
import com.ibm.rational.test.lt.execution.http.IRequestHeader;
import com.ibm.rational.test.lt.execution.http.ISSLInfo;
import com.ibm.rational.test.lt.execution.http.IServerConnection;
import com.ibm.rational.test.lt.execution.http.impl.HTTPAction;
import com.ibm.rational.test.lt.execution.http.impl.HTTPPage;
import com.ibm.rational.test.lt.execution.http.impl.HTTPParallel;
import com.ibm.rational.test.lt.execution.http.impl.HTTPPostData;
import com.ibm.rational.test.lt.execution.http.impl.HTTPRequest;
import com.ibm.rational.test.lt.execution.http.impl.HTTPThink;
import com.ibm.rational.test.lt.execution.http.impl.RequestHeader;
import com.ibm.rational.test.lt.execution.http.impl.ServerConnectionFactory;
import com.ibm.rational.test.lt.execution.http.util.HTTPDataArea;
import com.ibm.rational.test.lt.execution.protocol.IProxyServerInfo;
import com.ibm.rational.test.lt.kernel.IDataArea;
import com.ibm.rational.test.lt.kernel.action.IContainer;
import com.ibm.rational.test.lt.kernel.action.IKAction;
import com.ibm.rational.test.lt.kernel.action.IKTimeoutControl;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("all")
public class Test1_Test_A1DEA0B04424E350E5C5B53236353265 extends com.ibm.rational.test.lt.execution.protocol.impl.HTTPTestScript { 

    static ProtoAdapterHandler pa = new ProtoAdapterHandler();
    static {           
        pa.addPA("com.ibm.rational.test.lt.datacorrelation.execution.protocol.core.CoreProtoAdapter", "com.ibm.rational.test.lt.execution.core.impl.CDCAction");
pa.addPA("com.ibm.rational.test.lt.datacorrelation.execution.http.HTTPActionAdapter", "com.ibm.rational.test.lt.execution.http.impl.HTTPPostDataChunk");
pa.addPA("com.ibm.rational.test.lt.datacorrelation.execution.http.HTTPActionAdapter", "com.ibm.rational.test.lt.execution.http.impl.HTTPAction");
    }		
    
    private IDataCorrelationVar[] dcVars = DataCorrelationVar.getArrayDCVars(51);
    private DataVar[] vars = new DataVar[2];
    
    
    
 
    // not synchronized because it is only accessed by the thread creating the user
    Map scriptServerConnections = new HashMap();
    
    public Test1_Test_A1DEA0B04424E350E5C5B53236353265(IContainer container, String invocationId) {
        super(container, "test1", invocationId);
        setTimeoutDuration(240000);
        setTimeoutScheme(IKTimeoutControl.CONTINUE);
        setArmEnabled(true);        
    }
    
    public void execute() {
        
              this.add(varAction_1(this)); /* GENERIC CREATE TEMPLATE */

      this.add(page_1(this)); /* GENERIC CREATE TEMPLATE */

      this.add(page_2(this)); /* GENERIC CREATE TEMPLATE */

      this.add(page_3(this)); /* GENERIC CREATE TEMPLATE */

      this.add(page_4(this)); /* GENERIC CREATE TEMPLATE */

        super.execute();
    }
        
    public void finish(IKAction child) {
        super.finish(child);
    }    

    private VariableAction varAction_1(final IContainer parent) {

	VariableAction vc = new VariableAction(parent, "A1DEA0B04726FFC0E5C5B53236353265");	
		vars[0] = new DataVar("eb2-2241-grd03.csc.ncsu.edu_9080_Host", "String", (IDCCoreVar)null, "eb2-2241-grd03.csc.ncsu.edu", IDataArea.VIRTUALUSER);
	vc.add(vars[0]);
	
	vars[1] = new DataVar("eb2-2241-grd03.csc.ncsu.edu_9080_Port", "Integer", (IDCCoreVar)null, new Integer(9080), IDataArea.VIRTUALUSER);
	vc.add(vars[1]);
		
	return vc;
	
}
private HTTPPage page_1(final IContainer parent) {
		
		HTTPPage page = new HTTPPage(parent, "Plants by WebSphere", "A1DEA0B046B48EE7E5C5B53236353265") {
			public void execute() {                
			{ // Parallal Block Start
				HTTPParallel httpParallel = new HTTPParallel(6, this);
				this.add(httpParallel);

				// httpParallel.addRequest(int serial, HTTPAction action, int actionDelay, String firstCharSemID) 
				httpParallel.addRequest(0, request_1(this), 0, null);

				httpParallel.addRequest(0, request_2(this), 0, null);

				httpParallel.addRequest(0, request_3(this), 0, null);

				httpParallel.addRequest(1, request_4(this), 641, "A1DEA0B046C075CFE5C5B53236353265");

				httpParallel.addRequest(0, request_5(this), 0, null);

				httpParallel.addRequest(1, request_6(this), 0, null);

				httpParallel.addRequest(2, request_7(this), 1266, "A1DEA0B046C075CFE5C5B53236353265");

				httpParallel.addRequest(3, request_8(this), 1266, "A1DEA0B046C075CFE5C5B53236353265");

				httpParallel.addRequest(1, request_9(this), 0, null);

				httpParallel.addRequest(0, request_10(this), 0, null);

				httpParallel.addRequest(3, request_11(this), 0, null);

				httpParallel.addRequest(2, request_12(this), 0, null);

				httpParallel.addRequest(0, request_13(this), 0, null);

				httpParallel.addRequest(1, request_14(this), 0, null);

				httpParallel.addRequest(3, request_15(this), 0, null);

				httpParallel.addRequest(2, request_16(this), 0, null);

				httpParallel.addRequest(1, request_17(this), 0, null);

				httpParallel.addRequest(3, request_18(this), 0, null);

				httpParallel.addRequest(0, request_19(this), 0, null);

				httpParallel.addRequest(4, request_20(this), 1469, "A1DEA0B046C075CFE5C5B53236353265");

				httpParallel.addRequest(5, request_21(this), 1469, "A1DEA0B046C075CFE5C5B53236353265");

				httpParallel.addRequest(2, request_22(this), 0, null);

				httpParallel.addRequest(0, request_23(this), 0, null);

				httpParallel.addRequest(4, request_24(this), 0, null);
			} // Parallal Block End 


				super.execute();
			}
		};
		page.setArmEnabled(true);  
		return page;
	}

	private HTTPAction request_1(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "A1DEA0B046C075CFE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "UTF-8")	,			
			new RequestHeader("Accept-Language", "en-us", "UTF-8")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "UTF-8")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "UTF-8")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "UTF-8")	,			
			new RequestHeader("Connection", "Keep-Alive", "UTF-8")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "UTF-8")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_1 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_1);
	harvestContainer_1.addHarvestInstruction ("referer_uri", dcVars[0]);
	IDataSub subContainer_1 = new DataSub();
	reqAction.addDataSub(subContainer_1);

	subContainer_1.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_1.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_1.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_1.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
		
		

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			true,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"UTF-8",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(true);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_2(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_flowers_s.gif", "A1DEA0B046CC5CF0E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_2 = new DataSub();
	reqAction.addDataSub(subContainer_2);

	subContainer_2.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_2.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_2.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_2.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_2.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_flowers_s.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_3(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_veggies_s.gif", "A1DEA0B046CC5D49E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_3 = new DataSub();
	reqAction.addDataSub(subContainer_3);

	subContainer_3.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_3.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_3.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_3.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_3.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_veggies_s.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_4(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_trees_s.gif", "A1DEA0B046CECDDBE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_4 = new DataSub();
	reqAction.addDataSub(subContainer_4);

	subContainer_4.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_4.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_4.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_4.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_4.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_trees_s.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECDE1E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_5(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_flowers_u.gif", "A1DEA0B046CECE3CE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_5 = new DataSub();
	reqAction.addDataSub(subContainer_5);

	subContainer_5.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_5.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_5.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_5.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_5.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_flowers_u.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_6(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_accessories_s.gif", "A1DEA0B046CECE71E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_6 = new DataSub();
	reqAction.addDataSub(subContainer_6);

	subContainer_6.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_6.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_6.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_6.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_6.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_accessories_s.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECDE1E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_7(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_accessories_u.gif", "A1DEA0B046CECEEEE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_7 = new DataSub();
	reqAction.addDataSub(subContainer_7);

	subContainer_7.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_7.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_7.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_7.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_7.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_accessories_u.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECEF4E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_8(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_veggies_u.gif", "A1DEA0B046CECF2BE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_8 = new DataSub();
	reqAction.addDataSub(subContainer_8);

	subContainer_8.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_8.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_8.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_8.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_8.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_veggies_u.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECF31E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_9(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tab_trees_u.gif", "A1DEA0B046D13EEBE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_9 = new DataSub();
	reqAction.addDataSub(subContainer_9);

	subContainer_9.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_9.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_9.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_9.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_9.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tab_trees_u.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECDE1E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_10(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "A1DEA0B046D13F44E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_2 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_2);
	harvestContainer_2.addHarvestInstruction ("referer_uri", dcVars[1]);
	IDataSub subContainer_10 = new DataSub();
	reqAction.addDataSub(subContainer_10);

	subContainer_10.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_10.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_10.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_10.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_10.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/banner.html",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_11(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "A1DEA0B046D13F9DE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_3 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_3);
	harvestContainer_3.addHarvestInstruction ("resp_content", dcVars[3], "\\?action=(.*?)&", 7, 7, false, "action");
	harvestContainer_3.addHarvestInstruction ("resp_content", dcVars[4], "&category=(.*?)\"", 1, 1, false, "category");
	harvestContainer_3.addHarvestInstruction ("referer_uri", dcVars[2]);
	IDataSub subContainer_11 = new DataSub();
	reqAction.addDataSub(subContainer_11);

	subContainer_11.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_11.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_11.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_11.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_11.addSubInstruction("req_hdr_referer", false, dcVars[0]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/promo.html",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html");
		reqAction.setConnectionGroup("A1DEA0B046CECF31E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_12(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/1x1_trans.gif", "A1DEA0B046D13FF6E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_12 = new DataSub();
	reqAction.addDataSub(subContainer_12);

	subContainer_12.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_12.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_12.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_12.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_12.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F44E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/1x1_trans.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECEF4E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_13(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/PlantMaster.css", "A1DEA0B046D1402BE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_13 = new DataSub();
	reqAction.addDataSub(subContainer_13);

	subContainer_13.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_13.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_13.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_13.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_13.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F44E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/PlantMaster.css",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/css");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_14(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/pbw.jpg", "A1DEA0B046D388A0E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_14 = new DataSub();
	reqAction.addDataSub(subContainer_14);

	subContainer_14.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_14.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_14.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_14.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_14.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F44E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/pbw.jpg",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECDE1E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_15(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/applycss.js", "A1DEA0B046D388D5E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_15 = new DataSub();
	reqAction.addDataSub(subContainer_15);

	subContainer_15.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_15.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_15.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_15.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_15.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/applycss.js",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("application/x-javascript");
		reqAction.setConnectionGroup("A1DEA0B046CECF31E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_16(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/tabs_background.jpg", "A1DEA0B046D3899AE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_16 = new DataSub();
	reqAction.addDataSub(subContainer_16);

	subContainer_16.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_16.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_16.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_16.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_16.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F44E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/tabs_background.jpg",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECEF4E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_17(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/theme_summer1.gif", "A1DEA0B046D389CFE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_17 = new DataSub();
	reqAction.addDataSub(subContainer_17);

	subContainer_17.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_17.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_17.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_17.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_17.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/theme_summer1.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECDE1E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_18(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/theme_summer2.gif", "A1DEA0B046D38A04E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_18 = new DataSub();
	reqAction.addDataSub(subContainer_18);

	subContainer_18.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_18.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_18.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_18.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_18.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/theme_summer2.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECF31E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_19(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/trees_bonsai_48.jpg", "A1DEA0B046D38A39E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_19 = new DataSub();
	reqAction.addDataSub(subContainer_19);

	subContainer_19.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_19.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_19.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_19.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_19.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/trees_bonsai_48.jpg",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_20(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/flower_tulips_48.jpg", "A1DEA0B046D5F993E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_20 = new DataSub();
	reqAction.addDataSub(subContainer_20);

	subContainer_20.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_20.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_20.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_20.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_20.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F999E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046D5F999E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/flower_tulips_48.jpg",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F999E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046D5F999E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_21(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/veggies_strawberries_48.jpg", "A1DEA0B046D5F9D0E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_21 = new DataSub();
	reqAction.addDataSub(subContainer_21);

	subContainer_21.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_21.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_21.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_21.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_21.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/veggies_strawberries_48.jpg",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046D5F9D6E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_22(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/poweredby_WebSphere.gif", "A1DEA0B046D5FA31E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_22 = new DataSub();
	reqAction.addDataSub(subContainer_22);

	subContainer_22.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_22.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_22.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_22.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_22.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/poweredby_WebSphere.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046CECEF4E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_23(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/images/theme_summer_text.gif", "A1DEA0B046D5FA8AE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/promo.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_23 = new DataSub();
	reqAction.addDataSub(subContainer_23);

	subContainer_23.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_23.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_23.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_23.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_23.addSubInstruction("req_hdr_referer", false, dcVars[2]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046D13F9DE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/images/theme_summer_text.gif",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"iso-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/gif");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_24(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/favicon.ico", "A1DEA0B046DAB480E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_24 = new DataSub();
	reqAction.addDataSub(subContainer_24);

	subContainer_24.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_24.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_24.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_24.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046C075CFE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F999E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046D5F999E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/favicon.ico",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F999E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(404);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html;charset=ISO-8859-1");
		reqAction.setConnectionGroup("A1DEA0B046D5F999E5C5B53236353265");
		return reqAction;
	}
private HTTPPage page_2(final IContainer parent) {
			parent.add(new HTTPThink(2438, parent, parent, "A1DEA0B046DAB4D7E5C5B53236353265"));
		HTTPPage page = new HTTPPage(parent, "Shopping", "A1DEA0B046DAB4D7E5C5B53236353265") {
			public void execute() {                
			{ // Parallal Block Start
				HTTPParallel httpParallel = new HTTPParallel(12, this);
				this.add(httpParallel);

				// httpParallel.addRequest(int serial, HTTPAction action, int actionDelay, String firstCharSemID) 
				httpParallel.addRequest(0, request_25(this), 0, null);

				httpParallel.addRequest(1, request_26(this), 0, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(2, request_27(this), 0, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(3, request_28(this), 0, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(4, request_29(this), 16, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(0, request_30(this), 0, null);

				httpParallel.addRequest(5, request_31(this), 16, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(1, request_32(this), 0, null);

				httpParallel.addRequest(3, request_33(this), 0, null);

				httpParallel.addRequest(2, request_34(this), 0, null);

				httpParallel.addRequest(5, request_35(this), 0, null);

				httpParallel.addRequest(5, request_36(this), 0, null);

				httpParallel.addRequest(6, request_37(this), 1141, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(6, request_38(this), 0, null);

				httpParallel.addRequest(7, request_39(this), 1484, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(8, request_40(this), 1469, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(9, request_41(this), 1453, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(10, request_42(this), 1453, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(11, request_43(this), 1421, "A1DEA0B046DAB4DBE5C5B53236353265");

				httpParallel.addRequest(10, request_44(this), 0, null);
			} // Parallal Block End 


				super.execute();
			}
		};
		page.setArmEnabled(true);  
		return page;
	}

	private HTTPAction request_25(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "A1DEA0B046DAB4DBE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "iso-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "iso-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "iso-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "iso-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "iso-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "iso-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "iso-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "iso-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_4 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_4);
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[6], " src=\"(.*?)\"", 1, 1, false, "src11");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[7], " src=\"(.*?)\"", 2, 1, false, "src9");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[8], " src=\"(.*?)\"", 3, 1, false, "src10");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[9], " src=\"(.*?)\"", 4, 1, false, "src8");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[10], " src=\"(.*?)\"", 5, 1, false, "src7");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[11], " src=\"(.*?)\"", 6, 1, false, "src6");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[12], " src=\"(.*?)\"", 7, 1, false, "src3");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[13], " src=\"(.*?)\"", 8, 1, false, "src5");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[14], " src=\"(.*?)\"", 9, 1, false, "src4");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[15], " src=\"(.*?)\"", 11, 2, false, "src2");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[16], " src=\"(.*?)\"", 12, 1, false, "src");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[17], "\\?action=(.*?)&", 61, 26, false, "action2");
	harvestContainer_4.addHarvestInstruction ("resp_content", dcVars[18], "&category=(.*?)\"", 2, 2, false, "category2");
	harvestContainer_4.addHarvestInstruction ("referer_uri", dcVars[5]);
	IDataSub subContainer_25 = new DataSub();
	reqAction.addDataSub(subContainer_25);

	subContainer_25.addSubInstruction(new SubRule("req_uri", 68, 1, true,(IDCCoreVar)dcVars[4],  false));   
	subContainer_25.addSubInstruction(new SubRule("req_uri", 50, 8, true,(IDCCoreVar)dcVars[3],  false));   
	subContainer_25.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_25.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_25.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_25.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_25.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
		

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			true,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265"),   // server connection
			reqAction,
			"iso-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(true);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html;charset=ISO-8859-1");
		reqAction.setConnectionGroup("A1DEA0B046D5F9D6E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_26(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0001", "A1DEA0B046DAB538E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_26 = new DataSub();
	reqAction.addDataSub(subContainer_26);

	subContainer_26.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_26.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_26.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_26.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[6],  false));   
	subContainer_26.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_26.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0001",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECF31E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_27(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0003", "A1DEA0B046DAB571E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_27 = new DataSub();
	reqAction.addDataSub(subContainer_27);

	subContainer_27.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_27.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_27.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_27.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[8],  false));   
	subContainer_27.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_27.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0003",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_28(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0002", "A1DEA0B046DAB5AAE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_28 = new DataSub();
	reqAction.addDataSub(subContainer_28);

	subContainer_28.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_28.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_28.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_28.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[7],  false));   
	subContainer_28.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_28.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0002",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECEF4E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_29(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0004", "A1DEA0B046DAB5E3E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_29 = new DataSub();
	reqAction.addDataSub(subContainer_29);

	subContainer_29.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_29.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_29.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_29.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[9],  false));   
	subContainer_29.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_29.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0004",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECDE1E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECDE1E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_30(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0005", "A1DEA0B046DAB61CE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_30 = new DataSub();
	reqAction.addDataSub(subContainer_30);

	subContainer_30.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_30.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_30.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_30.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[10],  false));   
	subContainer_30.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_30.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0005",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046D5F9D6E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046D5F9D6E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_31(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0006", "A1DEA0B046DD25A4E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_31 = new DataSub();
	reqAction.addDataSub(subContainer_31);

	subContainer_31.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_31.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_31.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_31.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[11],  false));   
	subContainer_31.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_31.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0006",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046DD25AAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_32(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0008", "A1DEA0B046DD2605E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_32 = new DataSub();
	reqAction.addDataSub(subContainer_32);

	subContainer_32.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_32.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_32.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_32.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[13],  false));   
	subContainer_32.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_32.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0008",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECF31E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECF31E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_33(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0009", "A1DEA0B046DD267EE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_33 = new DataSub();
	reqAction.addDataSub(subContainer_33);

	subContainer_33.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_33.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_33.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_33.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[14],  false));   
	subContainer_33.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_33.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0009",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046CECEF4E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046CECEF4E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_34(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0007", "A1DEA0B046DD26B7E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_34 = new DataSub();
	reqAction.addDataSub(subContainer_34);

	subContainer_34.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_34.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_34.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_34.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[12],  false));   
	subContainer_34.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_34.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0007",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046C075D5E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046C075D5E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_35(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0011", "A1DEA0B046DF6FD0E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_35 = new DataSub();
	reqAction.addDataSub(subContainer_35);

	subContainer_35.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_35.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_35.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_35.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[15],  false));   
	subContainer_35.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_35.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0011",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046DD25AAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_36(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0012", "A1DEA0B046E1E090E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=0", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_36 = new DataSub();
	reqAction.addDataSub(subContainer_36);

	subContainer_36.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_36.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_36.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_36.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[16],  false));   
	subContainer_36.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_36.addSubInstruction("req_hdr_referer", false, dcVars[5]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=F0012",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046DD25AAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046DD25AAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_37(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "A1DEA0B046E1E0E9E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_5 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_5);
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[20], "\\?action=(.*?)&", 2, 2, false, "action4");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[21], "&inventoryID=(.*?)\"", 1, 1, false, "inventoryID7");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[22], "&inventoryID=(.*?)\"", 2, 1, false, "inventoryID5");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[23], "&inventoryID=(.*?)\"", 3, 1, false, "inventoryID4");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[24], "&inventoryID=(.*?)\"", 4, 1, false, "inventoryID2");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[25], "&inventoryID=(.*?)\"", 5, 1, false, "inventoryID6");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[26], "&inventoryID=(.*?)\"", 6, 1, false, "inventoryID");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[27], "&inventoryID=(.*?)\"", 7, 1, false, "inventoryID3");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[28], "\\?action=(.*?)&", 22, 2, false, "action3");
	harvestContainer_5.addHarvestInstruction ("resp_content", dcVars[29], "&category=(.*?)\"", 3, 3, false, "category3");
	harvestContainer_5.addHarvestInstruction ("referer_uri", dcVars[19]);
	IDataSub subContainer_37 = new DataSub();
	reqAction.addDataSub(subContainer_37);

	subContainer_37.addSubInstruction(new SubRule("req_uri", 68, 1, true,(IDCCoreVar)dcVars[18],  false));   
	subContainer_37.addSubInstruction(new SubRule("req_uri", 50, 8, true,(IDCCoreVar)dcVars[17],  false));   
	subContainer_37.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_37.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_37.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_37.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_37.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html;charset=ISO-8859-1");
		reqAction.setConnectionGroup("A1DEA0B046E1E0EFE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_38(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0001", "A1DEA0B046E1E14AE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_38 = new DataSub();
	reqAction.addDataSub(subContainer_38);

	subContainer_38.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[21],  false));   
	subContainer_38.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_38.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_38.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_38.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_38.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_38.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0001",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E0EFE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_39(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0005", "A1DEA0B046E1E183E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_39 = new DataSub();
	reqAction.addDataSub(subContainer_39);

	subContainer_39.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[25],  false));   
	subContainer_39.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_39.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_39.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_39.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_39.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_39.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0005",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E189E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_40(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0002", "A1DEA0B046E1E1C4E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_40 = new DataSub();
	reqAction.addDataSub(subContainer_40);

	subContainer_40.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[22],  false));   
	subContainer_40.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_40.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_40.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_40.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_40.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_40.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0002",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E1CAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_41(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0003", "A1DEA0B046E1E205E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_41 = new DataSub();
	reqAction.addDataSub(subContainer_41);

	subContainer_41.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[23],  false));   
	subContainer_41.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_41.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_41.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_41.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_41.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_41.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0003",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E20BE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_42(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0007", "A1DEA0B046E1E246E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_42 = new DataSub();
	reqAction.addDataSub(subContainer_42);

	subContainer_42.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[27],  false));   
	subContainer_42.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_42.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_42.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_42.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_42.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_42.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0007",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E24CE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_43(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0004", "A1DEA0B046E1E287E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_43 = new DataSub();
	reqAction.addDataSub(subContainer_43);

	subContainer_43.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[24],  false));   
	subContainer_43.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_43.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_43.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_43.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_43.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_43.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0004",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E28DE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_44(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0006", "A1DEA0B046E45246E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=1", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_44 = new DataSub();
	reqAction.addDataSub(subContainer_44);

	subContainer_44.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[26],  false));   
	subContainer_44.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[20],  false));   
	subContainer_44.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_44.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_44.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_44.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_44.addSubInstruction("req_hdr_referer", false, dcVars[19]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046DAB4DBE5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E1E0E9E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=V0006",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E24CE5C5B53236353265");
		return reqAction;
	}
private HTTPPage page_3(final IContainer parent) {
			parent.add(new HTTPThink(1407, parent, parent, "A1DEA0B046E69BB3E5C5B53236353265"));
		HTTPPage page = new HTTPPage(parent, "Shopping {1}", "A1DEA0B046E69BB3E5C5B53236353265") {
			public void execute() {                
			{ // Parallal Block Start
				HTTPParallel httpParallel = new HTTPParallel(6, this);
				this.add(httpParallel);

				// httpParallel.addRequest(int serial, HTTPAction action, int actionDelay, String firstCharSemID) 
				httpParallel.addRequest(0, request_45(this), 0, null);

				httpParallel.addRequest(1, request_46(this), 16, "A1DEA0B046E69BB7E5C5B53236353265");

				httpParallel.addRequest(2, request_47(this), 16, "A1DEA0B046E69BB7E5C5B53236353265");

				httpParallel.addRequest(3, request_48(this), 16, "A1DEA0B046E69BB7E5C5B53236353265");

				httpParallel.addRequest(4, request_49(this), 31, "A1DEA0B046E69BB7E5C5B53236353265");

				httpParallel.addRequest(5, request_50(this), 31, "A1DEA0B046E69BB7E5C5B53236353265");
			} // Parallal Block End 


				super.execute();
			}
		};
		page.setArmEnabled(true);  
		return page;
	}

	private HTTPAction request_45(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2", "A1DEA0B046E69BB7E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_6 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_6);
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[31], "\\?action=(.*?)&", 2, 2, false, "action6");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[32], "&inventoryID=(.*?)\"", 1, 1, false, "inventoryID9");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[33], "&inventoryID=(.*?)\"", 2, 1, false, "inventoryID8");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[34], "&inventoryID=(.*?)\"", 3, 1, false, "inventoryID12");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[35], "&inventoryID=(.*?)\"", 4, 1, false, "inventoryID11");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[36], "&inventoryID=(.*?)\"", 5, 1, false, "inventoryID10");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[37], "\\?action=(.*?)&", 16, 2, false, "action5");
	harvestContainer_6.addHarvestInstruction ("resp_content", dcVars[38], "&category=(.*?)\"", 4, 4, false, "category4");
	harvestContainer_6.addHarvestInstruction ("referer_uri", dcVars[30]);
	IDataSub subContainer_45 = new DataSub();
	reqAction.addDataSub(subContainer_45);

	subContainer_45.addSubInstruction(new SubRule("req_uri", 68, 1, true,(IDCCoreVar)dcVars[29],  false));   
	subContainer_45.addSubInstruction(new SubRule("req_uri", 50, 8, true,(IDCCoreVar)dcVars[28],  false));   
	subContainer_45.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_45.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_45.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_45.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_45.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
		

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			true,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(true);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html;charset=ISO-8859-1");
		reqAction.setConnectionGroup("A1DEA0B046E1E28DE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_46(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0003", "A1DEA0B046E69C14E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_46 = new DataSub();
	reqAction.addDataSub(subContainer_46);

	subContainer_46.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[34],  false));   
	subContainer_46.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[31],  false));   
	subContainer_46.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_46.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_46.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_46.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_46.addSubInstruction("req_hdr_referer", false, dcVars[30]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0003",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E0EFE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_47(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0004", "A1DEA0B046E69C4DE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_47 = new DataSub();
	reqAction.addDataSub(subContainer_47);

	subContainer_47.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[35],  false));   
	subContainer_47.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[31],  false));   
	subContainer_47.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_47.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_47.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_47.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_47.addSubInstruction("req_hdr_referer", false, dcVars[30]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0004",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E24CE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_48(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0005", "A1DEA0B046E69C86E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_48 = new DataSub();
	reqAction.addDataSub(subContainer_48);

	subContainer_48.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[36],  false));   
	subContainer_48.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[31],  false));   
	subContainer_48.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_48.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_48.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_48.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_48.addSubInstruction("req_hdr_referer", false, dcVars[30]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0005",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E1CAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_49(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0001", "A1DEA0B046E90C89E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_49 = new DataSub();
	reqAction.addDataSub(subContainer_49);

	subContainer_49.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[32],  false));   
	subContainer_49.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[31],  false));   
	subContainer_49.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_49.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_49.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_49.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_49.addSubInstruction("req_hdr_referer", false, dcVars[30]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0001",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E189E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_50(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0002", "A1DEA0B046E90CC2E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=2", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_50 = new DataSub();
	reqAction.addDataSub(subContainer_50);

	subContainer_50.addSubInstruction(new SubRule("req_uri", 68, 5, true,(IDCCoreVar)dcVars[33],  false));   
	subContainer_50.addSubInstruction(new SubRule("req_uri", 47, 8, true,(IDCCoreVar)dcVars[31],  false));   
	subContainer_50.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_50.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_50.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_50.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_50.addSubInstruction("req_hdr_referer", false, dcVars[30]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046E69BB7E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=T0002",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E20BE5C5B53236353265");
		return reqAction;
	}
private HTTPPage page_4(final IContainer parent) {
			parent.add(new HTTPThink(609, parent, parent, "A1DEA0B046EB7D60E5C5B53236353265"));
		HTTPPage page = new HTTPPage(parent, "Shopping {2}", "A1DEA0B046EB7D60E5C5B53236353265") {
			public void execute() {                
			{ // Parallal Block Start
				HTTPParallel httpParallel = new HTTPParallel(6, this);
				this.add(httpParallel);

				// httpParallel.addRequest(int serial, HTTPAction action, int actionDelay, String firstCharSemID) 
				httpParallel.addRequest(0, request_51(this), 0, null);

				httpParallel.addRequest(1, request_52(this), 31, "A1DEA0B046EB7D64E5C5B53236353265");

				httpParallel.addRequest(2, request_53(this), 31, "A1DEA0B046EB7D64E5C5B53236353265");

				httpParallel.addRequest(3, request_54(this), 31, "A1DEA0B046EB7D64E5C5B53236353265");

				httpParallel.addRequest(4, request_55(this), 31, "A1DEA0B046EB7D64E5C5B53236353265");

				httpParallel.addRequest(5, request_56(this), 31, "A1DEA0B046EB7D64E5C5B53236353265");

				httpParallel.addRequest(0, request_57(this), 0, null);

				httpParallel.addRequest(1, request_58(this), 0, null);

				httpParallel.addRequest(3, request_59(this), 0, null);

				httpParallel.addRequest(0, request_60(this), 0, null);

				httpParallel.addRequest(5, request_61(this), 0, null);

				httpParallel.addRequest(4, request_62(this), 0, null);
			} // Parallal Block End 


				super.execute();
			}
		};
		page.setArmEnabled(true);  
		return page;
	}

	private HTTPAction request_51(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "A1DEA0B046EB7D64E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/banner.html", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataHarvester harvestContainer_7 = new DataHarvester();
	reqAction.addDataHarvester (harvestContainer_7);
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[40], " src=\"(.*?)\"", 1, 1, false, "src22");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[41], " src=\"(.*?)\"", 2, 1, false, "src21");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[42], " src=\"(.*?)\"", 3, 1, false, "src19");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[43], " src=\"(.*?)\"", 4, 1, false, "src20");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[44], " src=\"(.*?)\"", 5, 1, false, "src18");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[45], " src=\"(.*?)\"", 6, 1, false, "src17");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[46], " src=\"(.*?)\"", 7, 1, false, "src16");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[47], " src=\"(.*?)\"", 8, 1, false, "src15");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[48], " src=\"(.*?)\"", 9, 1, false, "src14");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[49], " src=\"(.*?)\"", 10, 1, false, "src12");
	harvestContainer_7.addHarvestInstruction ("resp_content", dcVars[50], " src=\"(.*?)\"", 11, 1, false, "src13");
	harvestContainer_7.addHarvestInstruction ("referer_uri", dcVars[39]);
	IDataSub subContainer_51 = new DataSub();
	reqAction.addDataSub(subContainer_51);

	subContainer_51.addSubInstruction(new SubRule("req_uri", 68, 1, true,(IDCCoreVar)dcVars[38],  false));   
	subContainer_51.addSubInstruction(new SubRule("req_uri", 50, 8, true,(IDCCoreVar)dcVars[37],  false));   
	subContainer_51.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_51.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_51.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_51.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_51.addSubInstruction("req_hdr_referer", false, dcVars[1]);
		
		

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			true,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(true);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("text/html;charset=ISO-8859-1");
		reqAction.setConnectionGroup("A1DEA0B046E1E28DE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_52(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0001", "A1DEA0B046EB7DC1E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_52 = new DataSub();
	reqAction.addDataSub(subContainer_52);

	subContainer_52.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_52.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_52.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_52.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[40],  false));   
	subContainer_52.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_52.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0001",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E1CAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_53(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0002", "A1DEA0B046EB7DFAE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_53 = new DataSub();
	reqAction.addDataSub(subContainer_53);

	subContainer_53.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_53.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_53.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_53.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[41],  false));   
	subContainer_53.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_53.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0002",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E20BE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E20BE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_54(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0004", "A1DEA0B046EB7E33E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_54 = new DataSub();
	reqAction.addDataSub(subContainer_54);

	subContainer_54.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_54.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_54.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_54.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[43],  false));   
	subContainer_54.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_54.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0004",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E24CE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_55(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0003", "A1DEA0B046EB7E6CE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_55 = new DataSub();
	reqAction.addDataSub(subContainer_55);

	subContainer_55.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_55.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_55.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_55.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[42],  false));   
	subContainer_55.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_55.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0003",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E0EFE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_56(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0005", "A1DEA0B046EB7EA5E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_56 = new DataSub();
	reqAction.addDataSub(subContainer_56);

	subContainer_56.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_56.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_56.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_56.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[44],  false));   
	subContainer_56.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_56.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0005",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E189E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_57(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0006", "A1DEA0B046EB7EDEE5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_57 = new DataSub();
	reqAction.addDataSub(subContainer_57);

	subContainer_57.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_57.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_57.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_57.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[45],  false));   
	subContainer_57.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_57.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0006",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(false);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E28DE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_58(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0007", "A1DEA0B046F03890E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_58 = new DataSub();
	reqAction.addDataSub(subContainer_58);

	subContainer_58.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_58.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_58.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_58.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[46],  false));   
	subContainer_58.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_58.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0007",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E1CAE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E1CAE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_59(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0008", "A1DEA0B046F28260E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_59 = new DataSub();
	reqAction.addDataSub(subContainer_59);

	subContainer_59.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_59.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_59.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_59.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[47],  false));   
	subContainer_59.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_59.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0008",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E24CE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E24CE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_60(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0009", "A1DEA0B046F76440E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_60 = new DataSub();
	reqAction.addDataSub(subContainer_60);

	subContainer_60.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_60.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_60.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_60.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[48],  false));   
	subContainer_60.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_60.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0009",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E28DE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E28DE5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_61(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0011", "A1DEA0B046F76499E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_61 = new DataSub();
	reqAction.addDataSub(subContainer_61);

	subContainer_61.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_61.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_61.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_61.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[50],  false));   
	subContainer_61.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_61.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0011",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E189E5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E189E5C5B53236353265");
		return reqAction;
	}

	private HTTPAction request_62(IContainer parent) {
		HTTPAction reqAction = new HTTPAction(parent, "eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0010", "A1DEA0B046F764D2E5C5B53236353265");
		HTTPPage myPage = reqAction.getPage();
		
		// add the action to the page-global action map for possible semaphore use
		myPage.getActionMap().put(reqAction.getId(), reqAction);
				
	
		IRequestHeader headers[] = {
						
			new RequestHeader("Accept", "*/*", "ISO-8859-1")	,			
			new RequestHeader("Referer", "http://eb2-2241-grd03.csc.ncsu.edu:9080/PlantsByWebSphere/servlet/ShoppingServlet?action=shopping&category=3", "ISO-8859-1")	,			
			new RequestHeader("Accept-Language", "en-us", "ISO-8859-1")	,			
			new RequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; OfficeLiveConnector.1.4; OfficeLivePatch.1.3)", "ISO-8859-1")	,			
			new RequestHeader("Accept-Encoding", "gzip, deflate", "ISO-8859-1")	,			
			new RequestHeader("Host", "eb2-2241-grd03.csc.ncsu.edu:9080", "ISO-8859-1")	,			
			new RequestHeader("Connection", "Keep-Alive", "ISO-8859-1")	,			
			new RequestHeader("Cookie", "__utma=62336819.84538082.1240554301.1249173368.1249607099.16;__utmz=62336819.1240554301.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)", "ISO-8859-1")	
		};
			
		
		
		
		
		
		
			
		ISSLInfo sslInfo = null;
			
		IBasicAuthentication basicAuth = null; 

			IDataSub subContainer_62 = new DataSub();
	reqAction.addDataSub(subContainer_62);

	subContainer_62.addSubInstruction(new SubRule("req_hdr_Host_1", 28, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_62.addSubInstruction(new SubRule("sc_host", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_62.addSubInstruction(new SubRule("sc_port", 0, 4, false,(IDCCoreVar)vars[1],  false));   
	subContainer_62.addSubInstruction(new SubRule("req_uri", 0, 73, false,(IDCCoreVar)dcVars[49],  false));   
	subContainer_62.addSubInstruction(new SubRule("req_hdr_Host_1", 0, 27, false,(IDCCoreVar)vars[0],  false));   
	subContainer_62.addSubInstruction("req_hdr_referer", false, dcVars[39]);
		
				// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("Primary_A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));
		// wait on another action
		reqAction.addSemaphoreWait((IKAction)myPage.getActionMap().get("A1DEA0B046EB7D64E5C5B53236353265"));

		if (HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265") == null) {
			// create the server connection on first reference
			
			IProxyServerInfo proxyServerInfo = null;
			

				
		    
			IServerConnection serverConnection = 
				ServerConnectionFactory.create(
					"eb2-2241-grd03.csc.ncsu.edu",  // host name
					9080,  // port number
					sslInfo,  // SSL info
					null,  // NTLM info
					proxyServerInfo  // proxy server info
				);
			HTTPDataArea.putServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265", serverConnection);
		}

		IHTTPRequest req = new HTTPRequest(
			"GET",	// method
			"http",  // protocol - http or https
			"/PlantsByWebSphere/servlet/ImageServlet?action=getimage&inventoryID=A0010",						// url
			true,	// is url relative
			"1.1",	// version
			headers,					// headers
			IHTTPSessionTypes.STANDARD,
			0,							// delay
			false,	// isPrimary
			null,	// post data
			basicAuth,					// basic auth info
			(IServerConnection) HTTPDataArea.getServerConnection(parent, "A1DEA0B046E1E0EFE5C5B53236353265"),   // server connection
			reqAction,
			"ISO-8859-1",
			"ISO-8859-1"
		);

		req.setExpectedResponseCode(200);
		req.setConnectionClose(true);
		

		reqAction.setFirstRequestInParallel(false);
		reqAction.setRequest (req);
		reqAction.setArmEnabled(true);
		reqAction.setResponseContentType("image/jpeg");
		reqAction.setConnectionGroup("A1DEA0B046E1E0EFE5C5B53236353265");
		return reqAction;
	}
}
