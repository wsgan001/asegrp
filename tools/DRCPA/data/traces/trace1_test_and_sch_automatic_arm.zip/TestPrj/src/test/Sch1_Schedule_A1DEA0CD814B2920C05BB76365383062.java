/**@generated
 * WARNING ? Changes you make to this file may be lost.
 *           File is generated and may be re-generated without warning.
 */
package test;

import com.ibm.rational.test.lt.kernel.action.IContainer;
import com.ibm.rational.test.lt.kernel.action.IKThinkControl;
import com.ibm.rational.test.lt.kernel.action.impl.Container;
import com.ibm.rational.test.lt.kernel.action.impl.UserGroup;

public class Sch1_Schedule_A1DEA0CD814B2920C05BB76365383062 extends
		com.ibm.rational.test.lt.kernel.action.impl.Schedule {

	public Sch1_Schedule_A1DEA0CD814B2920C05BB76365383062(IContainer parent,
			String name) {
		super(parent, name, "A1DEA0CD814B2920C05BB76365383062");
		setThinkMax(10000);
		setThinkScheme(IKThinkControl.RECORDED);

	}

	public void execute() {
		this.addUserGroup(new UserGroup_1(this));

		super.execute();
	}

	public class UserGroup_1 extends UserGroup {

		public UserGroup_1(IContainer parent) {
			super(parent, "User Group 1", "A1DEA0CD81950360C05BB76365383062");
			setNumUsers(100);
			setLongRunMode(false); // *** LONG_RUN_MODE ***
			setLongRunLimit(100); // *** LONG_RUN_MODE ***

		}

		public IContainer createTesterWorkload(IContainer parent) {

			return scenario_1(parent);
		}

		private Container scenario_1(IContainer parent) {
			Container scenario = new Container(parent, "Default Scenario",
					"A1DEA0CD81977466C05BB76365383062") {

				public void reportStopMessage() {
				}

				public void reportForcedStopMessage() {
				}

				public void execute() {
					this
							.add(new test.Test1_Test_A1DEA0B04424E350E5C5B53236353265(
									this, "A1DEA0CD87187380C05BB76365383062") {
								public void execute() {
									this.setRtbEnabled(true);
									super.execute();
								}
							});

					this
							.add(new com.ibm.rational.test.lt.execution.protocol.impl.HTTPUserComplete(
									this));
					super.execute();
				}
			};

			return scenario;
		}

	}

}