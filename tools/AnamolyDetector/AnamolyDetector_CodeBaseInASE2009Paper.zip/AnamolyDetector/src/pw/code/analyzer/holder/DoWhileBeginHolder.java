package pw.code.analyzer.holder;

public class DoWhileBeginHolder extends Holder {
	
	public String toString() {
		return "DoWhileBeginHolder";
	}
	
}
