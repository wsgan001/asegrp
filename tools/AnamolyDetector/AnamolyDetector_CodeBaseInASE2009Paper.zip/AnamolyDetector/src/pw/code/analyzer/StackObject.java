package pw.code.analyzer;

/**
 * A super class for all stack objects
 * @author suresh_thummalapenta
 *
 */
public interface StackObject {

}
