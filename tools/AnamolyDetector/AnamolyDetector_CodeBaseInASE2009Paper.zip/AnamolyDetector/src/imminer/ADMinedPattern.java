package imminer;

public class ADMinedPattern {

}
