package imminer;

public class ADSinglePattern {

}
