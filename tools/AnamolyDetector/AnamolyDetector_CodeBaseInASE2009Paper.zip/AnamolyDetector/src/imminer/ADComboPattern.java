package imminer;

public class ADComboPattern {

}
