package imminer;

import imminer.core.IMMiner;
import imminer.core.MinerStorage;

/**
 * Migrates patterns from the IMMiner project into AnamolyDetector project
 * @author suresh
 *
 */
public class PatternMigrator {

	/**
	 * Location of all parent directories that need to be considered
	 * for mining patterns
	 */
	String[] parentDirs = new String[] 
	        {
				"D:\\NCSUASE\\MyPublicationMaterials\\Alattin_ASEJ2010\\NegExampleLearner\\JavaUtil_WithOldData"				
	        };
	
	/**
	 * Function that invokes IMMiner project's entry point for each 
	 * item in parentDir and gathers back the entire data 
	 * and transforms into local patterns for all mined
	 * patterns
	 */
	public void startProcess()
	{
		IMMiner mm = new IMMiner();
		
		for(String pdir : parentDirs)
		{
			MinerStorage ms = mm.startProcess(pdir);			
		}		
	}
	
	
}
