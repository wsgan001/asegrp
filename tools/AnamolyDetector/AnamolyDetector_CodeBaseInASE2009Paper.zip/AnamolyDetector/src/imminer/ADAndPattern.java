package imminer;

public class ADAndPattern {

}
